# @fairchild/folio

Folio is the calm, document-first conversation interface for agent-backed
applications. It owns presentation and typed view data — the transcript,
compose, status, approvals, tool ledger, diffs, receipts, and theme — while
the host that embeds it owns identity, persistence, transport, agent
execution, repositories, and publication authority.

React 19 and AI SDK 7 are peers; Folio itself is two Radix primitives and its
own code, and it ships one compiled stylesheet with no external font or image
asset in it.

## Installing

```bash
npm  add @fairchild/folio
pnpm add @fairchild/folio
yarn add @fairchild/folio
```

`0.3.0` is the first published version; until its tag lands, `pnpm
release:candidate` writes an installable tarball to `artifacts/`.

The same version publishes to GitHub Packages under the same name. That
registry asks for a token with `read:packages` even for a public package, so
npmjs is the default and GitHub Packages is there for hosts that prefer it; a
consumer who wants it points the scope at it in `.npmrc`:

```
@fairchild:registry=https://npm.pkg.github.com/
```

Every release is also a GitHub Release carrying the same `.tgz` with a
`SHA256SUMS` file and a `manifest.json` of per-file SHA-256 digests, for hosts
that pin a URL rather than a range. `sha256sum -c SHA256SUMS` is the check.

### Peers

React 19, React DOM 19, AI SDK 7, and `zod` are peers.

```bash
npm add react@^19 react-dom@^19 ai@^7 zod@^4
```

`zod` is there because `ai@7` requires it and is not optional about it, and no
manager except pnpm installs a peer's peer — so under npm and Yarn the first
sign of it used to be `Cannot find package 'zod'` at runtime. Folio declares it
on `ai`'s own range (`^3.25.76 || ^4.1.8`), which is what moves the news to
install time. Folio itself imports no `zod`.

Next 16 is the tested reference host — the clean-consumer fixture in the
release gate installs the packed tarball into a Next 16 app and builds it. The
supported range is recorded as advisory `folioCompatibility` metadata rather
than a peer, because Folio imports no Next.js API; Next 15.5 remains inside it.

### What the toolchain needs

Folio ships as ES modules only, on Node 22 or newer — the floor `ai@7` sets,
which Folio now matches rather than advertising a range its own peer cannot
satisfy. There is no CommonJS
build and there will not be one: `ai@7` is itself ESM-only, so a `require`
condition would resolve into a package that cannot be required — and a
dual-format build would give `/conversation` and `/testing` two different
`FolioUnknownCursorError` classes, which is the one thing the port contract
cannot survive. The release gate installs the packed tarball under npm, pnpm,
and both of Yarn 4's linkers and asserts that identity holds in each.

TypeScript resolves the declarations under `moduleResolution` of `bundler`,
`node16`, or `nodenext`. The legacy `node` mode reads neither `exports` nor the
subpath entries and will not find them.

Import only from the named entry point:

```tsx
import { SessionView, type SessionViewData } from "@fairchild/folio";
import "@fairchild/folio/styles.css";
```

The stylesheet compiles utilities from Folio source only and scopes every
selector to `data-folio-root`. `SessionView` supplies its own surface root;
`FolioRoot` is available when composing lower-level exports. Multiple instances
can coexist with host UI without resets or token values escaping the root.

Hosts own font loading and may override the narrow `--folio-*` token seam on an
ancestor or one instance. For example:

```css
:root {
  --folio-font-serif: var(--my-prose-font), Georgia, serif;
  --folio-accent: #8f4f2a;
  --folio-dark-accent: #dfa36c;
}
```

Full session surfaces default to `--folio-min-height: 100dvh`; embedded hosts
can set that token to `100%`, a pane height, or `auto` without changing package
CSS.

Folio currently has no external image or font asset paths: its small interface
marks are text/inline CSS. The exported sheet therefore contains the complete
visual dependency graph.

## The port

Hosts integrate through `FolioConversationPort`, not through component-specific
knowledge of their routes or runtimes. The port exposes a durable snapshot,
opaque resume cursor, ordered host-neutral events, and commands whose authority
remains with the host:

```ts
import {
  FolioConversationController,
  type FolioConversationPort,
} from "@fairchild/folio/conversation";

const controller = new FolioConversationController(hostPort satisfies FolioConversationPort);
await controller.hydrate();
await controller.follow(render);
```

When an established host runtime already owns and projects the current live
snapshot, seed the controller without a redundant async read, then recreate the
binding when that host snapshot changes. `follow()` begins at the seeded cursor
without calling `readSnapshot()` again:

```ts
const controller = FolioConversationController.fromSnapshot(hostPort, hostSnapshot);
```

Only one `follow()` may own a controller at a time. Hosts reconnect by creating
a controller from their durable snapshot cursor; unknown cursors fail closed
with `FolioUnknownCursorError` instead of replaying the conversation from the
beginning. A command receipt carries the first host cursor known to contain the
effect. Its cursor is `null` when a host accepted the command but an externally
owned projection has not observed it yet; callers then await the next snapshot
instead of assuming the old cursor includes new state.

Send commands carry a unique `requestId` for correlation and optional `retryOf`
UI provenance. A retry is a new send unless the host explicitly provides
stronger semantics; hosts may use `requestId` as a deduplication key, but Folio
does not claim that every transport does so.

`SessionView` receives one `FolioConversationActions` object. Missing callbacks
are missing capabilities; the component never discovers or constructs host
authority itself. A hydrated controller can derive that action membrane with
`createPortBackedConversationActions`, which requires a host error callback for
command failures. Derive it again after a capabilities, workspace, or
publication event so the UI reflects the latest host authority; the error
callback still closes the race if authority changes between render and click.
Tests and external adapters can use the deterministic fake without putting test
code in production imports:

```ts
import { FakeConversationPort } from "@fairchild/folio/testing";
```

## Where the page looks

`SessionView` scrolls the page while a turn streams, and it is on by default.
Sending docks the ask under the sticky chrome; the answer fills the space below
it while the page holds still; when the answer outgrows the page the reader is
carried along so they see it arrive. Scrolling up stops all of it and offers a
way back. Sending again overrides that — sending is the strongest intent there
is.

It works by putting a runway after the last turn, sized so it gives back
exactly what the streaming answer takes. The page height therefore does not
change for the whole turn, which is why the anchored position and the bottom of
the page are the same place and a turn costs one scroll call rather than a
per-token chase.

```tsx
<SessionView
  session={session}
  autoScroll            // default true
  scrollPreviousTurnPeek={120}
  defaultScrollPosition="last-anchor"  // or "bottom" | "top"
/>
```

The names come from shadcn's `MessageScroller`, which is solving the same
problem with the same principle — never move the reader against their intent.
The one deliberate divergence is that `autoScroll` defaults **true** here.
Theirs is opt-in because the component is generic; Folio's default without it
was a reply streaming in behind the composer, which is a bug rather than a
preference.

Two things a host owes the package for the geometry to be right:

- **`--folio-chrome-top`** — the height of any sticky chrome the host stacks
  above the surface. The masthead sticks below it, and the docked ask parks
  below the masthead. Default `0px`.
- **A page-scrolling layout.** Folio scrolls the document. A host that puts the
  surface inside its own scroll container should pass `autoScroll={false}` and
  drive that container itself; `data-turn-follow-scope` and
  `data-compose-boundary` are still there to select against.

Two more things a host should know. Give the surface a `key` that changes with
the session (`key={sessionId}`): a conversation swap on the same component
instance is not a first render, so it docks the new transcript's last turn
rather than applying `defaultScrollPosition`. And the geometry is read from the
offset chain, which a `position: fixed` ancestor terminates — a surface inside a
fixed panel is not a document scroller and wants `autoScroll={false}` for the
same reason a nested scroll container does.

While a following surface is mounted, Folio holds `overflow-anchor: none` on the
document element — native scroll anchoring would correct on top of the runway's
arithmetic. It is refcounted and restored on unmount, but it is page-global
while it lasts, so anything else growing in the same scroller loses native
anchoring too. That is also why Folio cannot preserve position across prepended
history (it does not paginate anyway): a host that prepends older turns should
record `scrollHeight - scrollY` before the insert and restore it after.

One known artifact: a streamed turn emits a single
`ResizeObserver loop completed with undelivered notifications.` on `window`.
Holding the page height still means measuring and resizing in the same frame the
browser is already delivering resizes in, and Chrome reports the deferred
delivery even though the correction lands and the position is right. It is one
event per turn, it does not reach `window.onunhandledrejection` or a Playwright
page-error hook, and it does reach anything listening on `window.onerror` — so a
host running Sentry will want that string filtered.

## What a tool row says

A tool call renders as one quiet row: a verb, what it was about, a figure on the
right, and a body that opens on click. All four are derived from the AI SDK
`dynamic-tool` part, so a host that already streams tool calls gets rows without
mapping anything.

- **The verb** is the tool's name, or the reading of it for the names coding
  agents have converged on: Read, Edit, Write ("Wrote"), Bash ("Ran"), Grep
  ("Searched"), Glob ("Listed"), Task ("Delegated"), TodoWrite ("Planned"),
  WebFetch, WebSearch. Anything else renders under its own name.
- **The subject** is the first thing the call's input names it by: `file_path`,
  `notebook_path`, `command`, `pattern`, `url`, `query`, `path`, `description`.
  A call that names none of them has no subject and the verb stands alone —
  "Planned" reads better than "Planned TodoWrite".
- **The figure** comes from the output: `summary` if the host provides one
  ("9 passed", "3 files"), an exact `+n −m` when the output carries a `diff`,
  a line count for a Read, or a test tally parsed out of the output.
- **The body** is the output's `content` — rendered as a diff when a `diff`
  rides with it, as highlighted test output when it looks like a test run, and
  as code otherwise.

So the shape a host returns is what steers the row:
`{ content }` for something the tool did, `{ content, summary }` to name the
figure, `{ content, diff }` for something it changed. A failed call
(`output-error`) renders its error text as the body and "failed" as the figure.

Contiguous tool calls render as one block (`[data-testid="workings"]`), and a
permission decision that let the work carry on renders inside it rather than
breaking it apart; a denial or a cancellation stands on its own, because no row
stands for a step that never ran.

The end-of-turn receipt is `metadata.turnStats`, and every figure but the tool
count and the duration is optional — including `costUsd`, which renders as
"$0.031" for a host running against something that prices a turn. A figure the
host does not know is a figure the receipt does not show, never a confident
zero.

## Entries

Server code that only needs the pure token formatter uses the side-effect-free
format entry instead of loading the React component barrel:

```ts
import { formatTokenCount } from "@fairchild/folio/format";
```

App layouts use the server-safe theme entry; interactive surfaces import the
explicit client control without collapsing those RSC boundaries:

```tsx
import { themeInitScript } from "@fairchild/folio/theme";
import { ThemeToggle } from "@fairchild/folio/theme-toggle";
```

The declared entries are `.`, `/conversation`, `/format`, `/theme`,
`/theme-toggle`, `/testing`, and `/styles.css`. All of them expose an import
condition and a default condition so the source-first package resolves in
Next.js, native ESM, and `tsx` CommonJS graphs.

Package-private source paths are not compatibility surfaces.

## Demo

`demo/` is a real host for Folio, built from this repository: a scripted
conversation authority serving `FolioConversationPort` over HTTP and
Server-Sent Events, bound to `SessionView` in the browser through the
package's own controller. Nine scripted scenarios cover the rendering states this
document describes — tool bursts, a long prose answer, approvals, failure, an
interrupt, review and publication, a queue, an empty session, a long transcript
— and
the page loads the built package from `dist/`, so what renders is what
ships. It is where design work starts from a rendered result instead of a
passing build.

```bash
pnpm demo
```

Two more scenarios join them when the machine can run one. With a provider key
(`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`) the **live agent** answers with a real
model — Read, Grep, Glob, Bash, Edit, Write, and a plan — against a disposable
workspace, with the picker in the status line switching model mid-session. With
a coding harness installed (`claude`, `codex`) a **harness** scenario puts Folio
in front of the agent itself: its own tools, its own model, and — for a harness
that asks — its permission questions answered on Folio's approval card. A
harness authenticates itself, so that lane needs no key here at all.

See [`demo/README.md`][demo-readme] for the scenario list, the two live lanes,
the HTTP surface, and what the demo found that this document now says (no
stylesheet preflight, the dock's sticky-chrome seam).

[demo-readme]: https://github.com/fairchild/folio/blob/main/demo/README.md
