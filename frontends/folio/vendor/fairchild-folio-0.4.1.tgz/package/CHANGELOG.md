# Changelog

## Unreleased

## 0.4.1 - 2026-08-22

Everything here came from looking at a rendered result rather than a passing
build — the first two from running a real coding harness against a real
repository, which is what `demo/` is for, and the rest from reading what that
run put on screen.

- A turn's allowed-step receipts no longer break the tool ledger apart. An
  approval part ended the run of contiguous tool parts, so a turn that asked
  eleven times rendered as twelve workings blocks with eleven paragraphs
  between them. A resolved *allow* now renders inside the block it belongs to,
  quiet and aligned under the rows' verbs; a *denial* or a cancellation keeps
  its own place, because no row stands for a step that never ran. Measured on
  the turn that prompted it: 41% of that section's height, and one block
  instead of twelve. **Hosts selecting `[data-testid="approval-receipt"]` will
  find an allowed one inside `[data-testid="workings"]` now** — the new test id
  on the block, which is also the one to select for the ledger itself.
- A ledger row only reads a test tally out of a tool that *ran* something (a
  Bash call, or any call given a `command`). A Read whose content happened to
  contain "28 passed" reported it as a test result — against a real repository,
  where a numbered line and the word "passed" are common, that fired on most
  reads, and a file's line count is what those rows should have said. The same
  gate applies to the highlighted test-output body.
- The diff hunk wraps instead of scrolling sideways. Long lines ran past the
  card's right edge and were cut mid-token, and the add/del tint stopped at the
  same fold because each line was sized to the box rather than to the widest
  line. The affordance that would say "this scrolls" is an OS scrollbar, which
  on macOS is an overlay taking no layout space and fading when idle — so on
  that platform there was nothing to see. Wrapping removes the failure rather
  than annotating it, and keeps the hunk readable at 320px.
- Every diff line carries a `+`, `-`, or blank mark in its own gutter column,
  so an addition no longer rests on colour alone: the add and del tints sit
  close in luminance and collapse under red-green colour blindness, and only
  deletions had the strikethrough to fall back on. The mark is `select-none`,
  so selecting a hunk still copies the code without it. `tab-size: 2`, because
  the default of 8 spent a third of a narrow card on indentation.
- The jump control is offered to a reader who left, not to one who arrived.
  `pinned` was answering two questions with one boolean — "the reader scrolled
  away" and "the first paint anchored above the live edge, because the last
  turn is taller than the page" — so a settled transcript nobody had touched
  offered to carry them somewhere they already were. The cost: a reader landing
  anchored at the top of an over-tall turn no longer gets an unprompted
  shortcut to its end, until they scroll.
- No change to the export map (`package.json` `exports`), the tarball layout,
  or the stylesheet contract.

## 0.4.0 - 2026-08-19

- A tool ledger row's subject now comes from the first key a call actually
  names it by — `file_path`, `notebook_path`, `command`, `pattern`, `url`,
  `query`, `path`, `description` — rather than from a file path or a command
  alone. A search used to render as "Grep Grep" with the pattern it searched
  for sitting unread in the input. **A call that names none of them now has an
  empty subject** and the row is its verb alone ("Planned"), where it used to
  repeat the tool's name.
- The verb table grows to the names coding agents have converged on: Grep
  ("Searched"), Glob ("Listed"), Task ("Delegated"), TodoWrite ("Planned"),
  WebFetch, WebSearch, MultiEdit and NotebookEdit ("Edit"). Anything outside
  the table still renders under its own name.
- Inline `**strong**` renders as `<strong>`. The parser knew `*emphasis*`
  only, so a model writing `**What was wrong:**` — which they do constantly —
  came out as a stray asterisk, an emphasis, and another stray asterisk.
- `TurnStatsData` gains an optional `costUsd`, rendered on the receipt as
  "$0.031" (three places under a dollar, two above). Nothing derives it: a host
  that knows what a turn cost can say so, and one that does not shows no money
  rather than "$0.00".
- No change to the export map (`package.json` `exports`), the tarball layout,
  or the stylesheet contract.

## 0.3.0 - 2026-08-19

The version that publishes. Nothing about the rendering, the port, or the
stylesheet contract changed; what changed is that a consumer can now reach
Folio by name from any of the three package managers.

- Published to npmjs as `@fairchild/folio`, and to GitHub Packages at the same
  name and version. `npm add`, `pnpm add`, and `yarn add` all work; GitHub
  Packages still wants a `read:packages` token, which is why npmjs is the
  default. Every release is also a GitHub Release carrying the same `.tgz`,
  `SHA256SUMS`, and the per-file digest manifest, for hosts that pin a URL.
- `.github/workflows/release.yml` publishes on a `v*` tag: one packed tarball
  to both registries and the Release, with an npm provenance attestation
  linking the bytes to the workflow run. `workflow_dispatch` with `dry_run`
  rehearses the whole path without contacting a registry.
- The published manifest drops `private` and gains `publishConfig`,
  `keywords`, `author`, `homepage`, `bugs`, `engines` (`node >=22`), and
  `main` alongside `module` for resolvers that predate `exports`. The source
  manifest at the repository root stays `private` — its `exports` point at
  TypeScript under `src/`, which is not what ships. `repository.url` is now
  the canonical `git+https://` form that provenance matches against.
- The export map gains `"./package.json"`. Tooling that reads a dependency's
  manifest — and Yarn's PnP linker among it — asks for that path by name.
- New gate step, `pnpm release:managers`: installs the packed candidate under
  npm, pnpm, and both of Yarn 4's linkers, and proves in each that every
  export subpath resolves, both client entries and both server entries
  evaluate, `/conversation` and `/testing` still share one
  `FolioUnknownCursorError`, and the stylesheet arrives compiled. The npm
  fixture also typechecks the shipped declarations under `moduleResolution`
  `bundler` and `node16`. `pnpm verify` runs it.
- `release:candidate` now writes `artifacts/SHA256SUMS` next to the tarball.
- The release workflow passes the tarball as `./artifacts/…`. npm reads a bare
  `a/b` argument as a GitHub `user/repo` shorthand and tries `git ls-remote` on
  it, so the publish step would have failed on a path that looks like a file.
  Found by rehearsing both legs locally with `npm publish --dry-run`, which
  contacts no registry — the hosted `workflow_dispatch` rehearsal has never run,
  because Actions refuses to start a job on this repository while billing is
  blocked.
- `main` and `module` stay in the published manifest. Every resolver that reads
  `exports` never sees them, and dropping them would change nothing for a modern
  consumer — only which error a pre-`exports` bundler reports.
- The README says what the toolchain needs, which the package managers
  disagreed about: Folio is ESM-only on purpose — `ai@7` is itself ESM-only,
  and a dual-format build would hand `/conversation` and `/testing` two
  different `FolioUnknownCursorError` classes.
- `zod` is a declared peer, on `ai@7`'s own range (`^3.25.76 || ^4.1.8`).
  Folio imports no `zod`; `ai@7` requires it and is not optional about it, and
  no manager except pnpm installs a peer's peer — so npm and Yarn consumers met
  it as `Cannot find package 'zod'` at first import. Declaring it moves that to
  an install-time warning every manager gives.
- `engines.node` is `>=22`, up from `>=18.18.0`. The old floor could not be
  satisfied: `ai@7` declares `engines: {"node": ">=22"}` itself, so no consumer
  on Node 18 or 20 could install a working graph, and both of those lines are
  past end of life. Node 22 is also what this repository builds and tests on.
- Next 16 is the tested reference host. The clean-consumer fixture builds a
  Next 16 app against the packed tarball, and `folioCompatibility.next` widens
  to `>=15.5.0 <17` — Next 15.5 stays inside the range, but the version a new
  consumer actually starts from is the one now under test.

## 0.2.0 - 2026-08-18

- `SessionView` now scrolls the page while a turn streams, on by default.
  Sending docks the ask under the sticky chrome, the answer fills the space
  below it while the page holds still, and following begins when the answer
  outgrows the page. Scrolling up releases; a jump control offers the way back;
  sending again overrides a release. **Both hosts must delete their own
  turn-follow animator when they take this version** — two mechanisms driving
  one scroller fight each other.
- Three new `SessionView` props, named after shadcn's `MessageScroller`:
  `autoScroll` (default `true`, where theirs defaults `false`),
  `scrollPreviousTurnPeek` (default `120`), and `defaultScrollPosition`
  (`"last-anchor"` | `"bottom"` | `"top"`, default `"last-anchor"`).
- The masthead sticks to `top: var(--folio-chrome-top, 0px)`, and its wrapper
  carries `data-folio-chrome`. A host with its own sticky bar sets the token
  instead of overriding the masthead structurally.
- `FolioRoot` accepts a `ref`. The root entry also exports
  `DEFAULT_SCROLL_PREVIOUS_TURN_PEEK` and the `FolioScrollPosition` type.
- A completed turn is announced through one persistent visually-hidden status
  region rather than by making the turn's own frame a live region — a region
  that goes live after its content settled has no mutation left to announce.
- While a following surface is mounted, Folio holds `overflow-anchor: none` on
  the document element (refcounted, restored on unmount). Native scroll
  anchoring would correct on top of the runway.
- Every scroll is issued with `behavior: "instant"`. Two-argument `scrollTo`
  resolves against the host's computed `scroll-behavior`, so a host with
  `scroll-smooth` on `<html>` got no docking, no following, and no jump
  control at all.
- A streamed turn emits one `ResizeObserver loop completed with undelivered
  notifications.` on `window` — the cost of measuring in the frame the browser
  is already delivering resizes in. Position is unaffected; hosts running an
  error monitor will want the string filtered.
- The jump control works with text selected. The selection guard stops the
  page moving on its own; it does not get to veto the reader asking it to.
- The demo's bar gained a `follow` toggle for `autoScroll` (`?follow=off`).
- No change to the export map (`package.json` `exports`), the tarball layout,
  or the stylesheet contract.

Also carried by this version, from the repository extraction that had not
shipped under a number yet:

- Extracted to its own repository, `github.com/fairchild/folio`, with history
  from `fairchild/workspaces`. Private for now; the source is unchanged from
  the released `0.1.0`.
- Build, test, and release candidate now run standalone here (`pnpm build`,
  `pnpm test`, `pnpm release:candidate`) with CI running the same sequence on
  pushes to `main` and on pull requests.
- Retired the `accepted-release.json` gate that verified a locally packed
  artifact against a remote tag and release asset from inside the monorepo;
  the release candidate is now the whole local and CI proof.
- The release manifest now carries a per-file SHA-256 of every packed path,
  not just a checksum of the tarball as a whole.
- Added `demo/`: a scripted host serving `FolioConversationPort` over HTTP
  and Server-Sent Events, with nine scenarios covering the package's
  rendering states, bound to `SessionView` in the browser against the built
  `dist/` output. Run it with `pnpm demo`.
- The demo can run a real agent: with `OPENAI_API_KEY` set it lists a `live`
  scenario whose turns come from `streamText` rather than a script, with Read
  unasked and Bash and Edit gated by Folio's own approval card, against a
  disposable copy of a fixture project. Demo-only — the package gains no
  dependency, and `pnpm test` still needs no key.

## 0.1.0 - 2026-07-12

- First versioned Folio conversation artifact.
- Document-first session UI, messages, approvals, tool ledger, diffs, receipts,
  compose, status, themes, and scoped standalone styles.
- Host-neutral snapshot/event/command port, shared-runtime controller entry, and
  deterministic fake.
- Server-safe formatter and theme initialization entries; explicit client theme
  control entry.

Released from `fairchild/workspaces` as `folio-v0.1.0`, and installed by hosts
from that release's tarball. Not on a public registry.
